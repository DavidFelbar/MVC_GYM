<?php
session_start();
unset($_SESSION['login']);
unset($_SESSION['tip']);
session_destroy();
header("Location: ../index.php");
?>

